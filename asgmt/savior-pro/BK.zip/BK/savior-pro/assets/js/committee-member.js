jQuery(document).ready(function() {
    'use strict';
    Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
    });
});